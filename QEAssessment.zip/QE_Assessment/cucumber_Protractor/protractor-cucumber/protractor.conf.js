// var cucumberReportDirectory = 'ExecutionReport';
// var jsonReportFile = cucumberReportDirectory + '/cucumber_report.json';

exports.config = {
  seleniumAddress: 'http://localhost:4444/wd/hub',

  framework: 'custom',
  frameworkPath: require.resolve('protractor-cucumber-framework'),

  specs: [
    'features/opencart.feature'
  ],
  cucumberOpts: {
    require: ['env.js','hooks.js','features/steps/opencart_steps.js'],
    format: 'pretty'
	//format: 'json:./' + jsonReportFile,
  }
}
