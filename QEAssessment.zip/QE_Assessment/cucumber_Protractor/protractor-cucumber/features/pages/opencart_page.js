
var OpencartPage = function() {

  this.get= function() {
	  
	browser.get('https://www.opencart.com/').then(function(){
		callback();
	});
  };
  
  this.getTitle= function(){
	 return element(by.xpath('//a[@class="navbar-brand"]/img')).getAttribute('title');
  };

  this.selectLogin = function() {
    element(by.linkText('Login')).click();
  };

  this.setUserName = function(value) {
    element(by.id('input-email')).sendKeys(value);
  };

  this.setPassword = function(value) {
    element(by.id('input-password')).sendKeys(value);
  };

  this.loginToOpencart = function() {
     element(by.buttonText('Login')).click();
  };
  
  this.GetErrorMessage = function(){
	  return element(by.xpath('//div[@class = "alert alert-danger"]')).getText();
  };

  this.closeBrowser = function() {
    browser.close();
  }
};

module.exports = OpencartPage;
