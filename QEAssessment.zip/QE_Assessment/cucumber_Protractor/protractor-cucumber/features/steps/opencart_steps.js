var chai = require('chai').use(require('chai-as-promised'));
var expect = chai.expect;

var OpencartSteps = function() {

  var OpencartPage = require("../pages/opencart_page.js");
 // var OpencartPage = require("C:/Users/User/Desktop/AnuZZZ/cucumber_Protractor/protractor-cucumber/features/pages/opencart_page.js");
  //this.page = new OpencartPage();
  
  this.World = function MyWorld() {
    this.page = new OpencartPage();
  };

  this.Given('I am on the opencart homepage',{timeout: 3 * 5000}, function (callback) {
		browser.ignoreSynchronization = true;
		browser.get('https://www.opencart.com/').then(function(){
			callback();
		});
  });
  
  this.When('I select Login Link', function (callback) {
    this.page.selectLogin();
    callback();
	
  });

  this.When('enter invalid values as $username and $password', function (username, password, callback) {
    this.page.setUserName(username);
    this.page.setPassword(password);
    callback();
  });

  this.When('select Login button', function (callback) {
    this.page.loginToOpencart();
    callback();
  });

  this.When('close the browser and exit the test', function (callback) {
    this.page.closeBrowser();
    callback();
  });

  this.Then('the title should be $title', function (title,callback) {
    expect(this.page.getTitle()).to.eventually.equal(title).and.notify(callback);
  });
  
  this.Then('error $message is shown', function (message,callback) {
	expect(this.page.GetErrorMessage()).to.eventually.contain(message).and.notify(callback);
  });
  
};

module.exports = OpencartSteps;