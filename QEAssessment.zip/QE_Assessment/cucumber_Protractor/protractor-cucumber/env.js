var configure = function(){
	this.setDefaultTimeout(90 * 1000);
};
module.exports = configure;