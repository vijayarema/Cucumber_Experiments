var chai = require('chai').use(require('chai-as-promised'));
const fs = require('fs');
var expect = chai.expect;
var getURL;
var postURL,payload,soapURL,headers,xml;
var timeout = 10000;

var ServiceSteps = function() {

  var ServicePage = require("../Pages/Service_page.js");
  var Data = require('../Data/testData.json');
 // var OpencartPage = require("C:/Users/User/Desktop/AnuZZZ/cucumber_Protractor/protractor-cucumber/features/pages/opencart_page.js");
  //this.page = new OpencartPage();
  
  this.World = function MyWorld() {
    this.page = new ServicePage();
  };
  
  this.Given('I make the get service call with $GetURL', function(GetURL,callback){ 
		getURL = Data.GetURL;		
		callback();
	});

  this.Given('I make the post service call with $PostURL', function (PostURL,callback) {
	  postURL = Data.PostURL;
	  callback();
	
  });
  
  this.Given('I make the soap service call with $SoapURL', function (SoapURL,callback) {
	soapURL = Data.SoapURL;		
	callback();
  });
  
  this.Then('the response status code should be $StatusCode and UserId should be $UserID', function (StatusCode, UserID, callback) {
	  this.page.GetRequest(getURL,StatusCode,UserID);
	  callback();
  });

  this.When('made with $payload', function (payload,callback) {
	  payload = Data.payload;
	  callback();
  });

   
  this.Then('the response status code should be $StatusCode and ID should be $ID', function (StatusCode,ID,callback) {
	this.page.PostRequest(postURL,payload,StatusCode,ID);
	callback();
  });
  
  this.When('with the header data $headers', function (headers,callback) {
	  headers = Data.headers;
	  callback();
  });
  
   this.When('provided the xml $xml', function (xml,callback) {
	  xml = fs.readFileSync('C:/Users/User/Desktop/AnuZZZ/API framework/Data/'+xml+'.xml', 'utf-8');
	  
	  callback();
  });
  
  this.Then('the response statuscode should be $StatusCode', function (StatusCode,callback) {
	this.page.SoapRequest(soapURL,headers,xml,timeout,StatusCode);
	callback();
  });
  
};

module.exports = ServiceSteps;