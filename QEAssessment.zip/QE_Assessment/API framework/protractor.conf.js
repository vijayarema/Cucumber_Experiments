
exports.config = {
  seleniumAddress: 'http://localhost:4444/wd/hub',

  framework: 'custom',
  frameworkPath: require.resolve('protractor-cucumber-framework'),

  specs: [
    'features/TestAPISpec.feature'
  ],
  cucumberOpts: {
    require: ['hooksReport.js','steps/Service_calls.js'],
    format: 'pretty'
	//format: 'json:./' + jsonReportFile,
  }
}
