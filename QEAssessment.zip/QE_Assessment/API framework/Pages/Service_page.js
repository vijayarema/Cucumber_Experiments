var req = require('request');
var assert = require('assert');
const soapRequest = require('easy-soap-request');
const fs = require('fs');

var ServicePage = function() {

  this.GetRequest= function(url,statuscode,userid) {
	  
	req.get(url,function(err,res,body){
			if(err)
			{
				console.log('error in get request');
			}
			assert(res.statusCode = statuscode,'Bad request performed');
			console.log(body);
			assert(body.userId = userid,'Invalid UserId value received as response data for the get request performed');
			
			
		});
  };
  
  this.PostRequest= function(url,options,StatusCode,ID){
	 req.post(url,options,function(err,res,body){
			if(err)
			{
				console.log('error in post request');
			}
			console.log(res.statusCode);
			assert(res.statusCode = StatusCode,'Bad request performed');
			console.log(body);
			assert(body.id = ID,'Invalid id value received as response data for the post request performed');
			
			
		});
  };
  
  this.SoapRequest = function(soapURL,headers,xml,timeout,StatusCode){
	(async () => {
		try{
		  const { response } = await soapRequest(soapURL, headers, xml, timeout); // Optional timeout parameter(milliseconds)
		  const { body, statusCode } = response;
		  console.log(body);
		  console.log(statusCode);
		  //console.log(response);
		  assert(statusCode = StatusCode,'Bad request performed');
		}
		catch(e){
			console.log('error'+e);
		}
	})();
  };
  
};

module.exports = ServicePage;
