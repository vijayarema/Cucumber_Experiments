var req = require('request');
var assert = require('assert');
var url = 'https://jsonplaceholder.typicode.com/posts';
var options ={
      title: 'foo',
      body: 'bar',
      userId: 1,
	  "Content-type": "application/json; charset=UTF-8"
}



req.post(url,options,function(err,res,body){
	if(err)
	{
		console.log('error');
	}
	console.log(res.statusCode);
	assert(res.statusCode = 201,'Bad request performed');
	console.log(body);
	assert(body.id = 101,'Invalid id value received as response data for the post request performed');
	
	
});