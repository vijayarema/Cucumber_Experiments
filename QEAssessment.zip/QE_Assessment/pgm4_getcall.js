var req = require('request');
var assert = require('assert');
var url = 'https://jsonplaceholder.typicode.com/posts/1';

req.get(url,function(err,res,body){
	if(err)
	{
		console.log('error');
	}
	assert(res.statusCode = 200,'Bad request performed');
	console.log(body);
	assert(body.userId = 1,'Invalid UserrId value received as response data for the gdet request performed');
	
	
});