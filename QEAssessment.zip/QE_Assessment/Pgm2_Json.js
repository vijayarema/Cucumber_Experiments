var fs = require('fs');
var fileName = './TestData.json';
var file = require(fileName);

file.department = "History";
file.car = "Benz";

fs.writeFile("UpdatedJson_file", JSON.stringify(file), function (err) {
  if (err) return console.log(err);
  console.log(JSON.stringify(file));
  console.log('writing to UpdatedJson_file');
});